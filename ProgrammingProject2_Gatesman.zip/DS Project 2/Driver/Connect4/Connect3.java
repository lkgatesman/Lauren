package Connect4;

//import java.util.Scanner;

public class Connect3 {
	//make variable to hold whose turn it is (p1 = blue, p2 = red)
	static int player;
			
	//make variables for blue and red players
	final static int B = 1;
	final static int R = 2;
	
	//make 2 variables to keep track of blue (p1) wins and red (p2) wins
	static int p1;
	static int p2;
	
	//make variable to count number of recursion calls
	static long count;
	
	//make variables for board dimensions
	//3x3 Connect3 board, so set each to 3
	static int num_Columns = 3;
	static int num_Rows = 3;
	
	public static void main(String[] args) {
		
			
		
		/*we want to see the different wins/losses/ties for when the first player makes their first move in 
		 * column1, column2, column3, and column4
		 * so, we need to create a for loop that will create each of these scenarios and then recursively 
		 * call the play() method
		*/
		for (int j = 0; j < num_Columns; j++) {
			
			//declare 4x4 Connect4 board as an Array
			int[][] board = new int[num_Columns][num_Rows];
			
			//initialize all spots in the Connect4 board as 0
			//this step is important for when the isFull method checks if the board is full
			for (int i = 0; i < num_Columns; i++) {
				for (int i2 = 0; i2 < num_Rows; i2++) {
					board[i][i2] = 0;
				}
			}
		
			//set p1 wins, p2 wins, and recursion count to 0
			p1 = 0;
			p2 = 0;
			count = 0;
			
			/*depending on which column you are working with (1, 2, 3, or 4), do the first turn
			for player1 = B = 1*/
			switch(j) {
				case 0: board[num_Rows - 1][0] = B; break; //first move in first column
				case 1:	board[num_Rows - 1][1] = B; break; //first move in second column
				case 2: board[num_Rows - 1][2] = B; break; //first move in third column
				case 3: board[num_Rows - 1][3] = B; break; //first move in fourth column
				default: break;
			}
			
			//call recursive play method starting with next move (player2 = R is next move)
			Play(board, R);
			
			//print out appropriate final data
			System.out.println("COLUMN " + (j+1));
			System.out.println("P1 Net Wins: " + (p1 - p2));
			System.out.println("P1 Wins: " + p1 + "\t P2 Wins: " + (p2));
			System.out.println("Total Recursive Calls: " + count);
			System.out.println("");
		
		}
	}
	
	public static int Play(int[][] inBoard, int player) {
		//increase recursion count by 1
		count++;
		
		//check if there is a winner, if there is a tie, or if we should keep playing
		int nextStep = checkBoard(inBoard, player);
		
		//if nextStep = 0 it's a tie, if nextStep is 1 or 2, give win to respective player, if nextStep = 3, keep playing
		if (nextStep < 3) {
				if (nextStep == 1) { p1++; return 1; }	//if the game is won by p1 (nextStep = 1) or by p2 (nextStep = 2)
				else if (nextStep == 2){ p2++; return -1; }
				else { return 0; } 
		}
		
		//if nextStep = 3, then keep playing
		
		//get "neighbors" of current board, for each possible move for this player, 
		//get a board where the player has played that move
		
		//store next boards in a List of Arrays (list of boards)
		List<int[][]> NextBoards = new ArrayList<int[][]>();
		NextBoards = getNeighbors(inBoard, player, num_Columns, num_Rows);
		
		//recurse on each new board given by getNeighbors() function
		for (int i = 0; i < NextBoards.size(); i++) {
			Play(NextBoards.get(i), 3 - player);
		}
		
		return 0;
	}
	
	/*checkBoard method will check if a connect4 (horizontal, vertical, or diagonal) 
	 * has been made by the last player to take a turn, or if the board is a TIE board
	*/
	public static int checkBoard(int[][] inBoard, int player){ 
		
		//set a check color variable to keep track of whether we should be checking for a BLUE or RED connect4
		//So, if BLUE just took a turn, then we want to be checking for a BLUE connect4, and same if RED just took a turn
		int check_Color = 3-player;
		
		//set a color counter variable that will keep track of if a player has made a connect4 successfully
		int color_Counter = 0;
		
		//check for horizontal, vertical, or diagonal connect4's
		//if there is one, return check_Color so that the Play() method counts it as a win for that player (B=1, R=2)
		
		//HORIZONTAL connect4 checker
		for (int i = 0 ; i < num_Rows; i++ ) {
			
			color_Counter = 0;
			
			for (int j = 0; j < num_Columns; j++) {
				if (inBoard[i][j] == check_Color) {
					color_Counter++;
					if (color_Counter == num_Rows)  { return check_Color; }	 
				}  
				//if there is no Connect4 found in this row, move onto 
				else { continue; }
			}
		}
		
		//VERTICAL connect4 checker
		for (int i = 0 ; i < num_Columns; i++ ) {
			
			color_Counter = 0;
			
			for (int j = 0; j < num_Rows; j++) {
				if (inBoard[j][i] == check_Color) {
					color_Counter++;
					if (color_Counter == num_Rows)  { return check_Color; }	 
				}  
				//if there is no Connect4 found in this loop, reset color_Count to 0 to check other VERTICAL possibilities
				else { continue; }
			}
		}

		//reset color counter as 0 to check for diagonal connect4
		color_Counter = 0; 
		
		//DIAGONAL connect4 checker (left to right diagonal)
		for (int i = 0 ; i < num_Columns; i++ ) {
			
			if (inBoard[i][i] == check_Color) {
				
				color_Counter++;
				if (color_Counter == num_Rows)  { return check_Color; }	 
				
			} 
		}
		
		//reset color counter as 0 to check for other diagonal connect4
		color_Counter = 0;
		
		//DIAGONAL connect4 checker (right to left diagonal)
		for (int i = 0 ; i  < num_Columns; i++ ) {
			if (inBoard[num_Columns-1-i][i] == check_Color) {
				color_Counter++;
				if (color_Counter == num_Rows)  { return check_Color; }	 
			}  
		}
		
		//if board is Full, it's a tie
		if (isFull(inBoard)) {  return 0; }
		
		/* if the board doesn't meet any of the above requirements (doesn't have a connect4, and isn't a tie),
		 then return 3 to keep playing (to keep making moves). */
		return 3;
	}
	
	//method to check if the board is full (all spaces in board are filled)
	public static boolean isFull(int[][] inBoard){
		
		for (int[] row : inBoard) {
			for (int element : row) {
				if (element == 0) { return false; }
			}
		}
		
		//return true if board is Full
		return true;
		
	}

	//this method will be (1) determining the next possible moves for the current turn (4 possible moves)
	//and (2) making a copy of the board
	public static List<int[][]> getNeighbors(int[][] inBoard, int player, int columns, int rows) {
		List<int[][]> neighbors = new ArrayList<int[][]>();
		
		int listIndex = -1;
		
		for (int i = 0; i < columns; i++) {
			for (int j = rows - 1; j >= 0; j--) {
				if (inBoard[j][i] == 0) {
					
					//this is an available spot, so make a clone of the board
					int[][] cloneBoard = new int[rows][columns];
					
					//fill the board with the already taken spots
					for (int x = 0; x < columns; x++) {
						for (int y = 0; y < rows; y++) {
							cloneBoard[y][x] = inBoard[y][x];
						}
					}
					
					//make the player's "turn" 
					//fill the available spot with the player's number (1 or 2)
					cloneBoard[j][i] = player;
					
					//add the cloneBoard to the list of neighbor boards
					listIndex += 1;
					neighbors.add(listIndex,  cloneBoard);
					
					//break the for loop to move onto the next column for the next possible turn
					break;
				}
				//if the spot is already taken, move onto the next higher spot in the column
				else if(inBoard[j][i] != 0) {
					continue;
				}
				
				//if all spots in the column are already taken, then move onto the next column
				else if((j == 0) && (inBoard[j][i] != 0)) {
					break;
				}
			}
		}
		
		return neighbors;
	}
	
}