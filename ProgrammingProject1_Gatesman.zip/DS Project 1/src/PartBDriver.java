import java.util.Random; //import Random so that we can generate Random numbers to fill the SinglyLinkedList with processes/info
import net.datastructures.*; //import to use methods of SinglyLinkedList Object

public class PartBDriver {
	public static void main(String[] args) {
		
		//create instance of Random class to generate random numbers
		Random rand = new Random();
		
		//declare SinglyLinkedList
		SinglyLinkedList<String> myList;
		myList = new SinglyLinkedList<String>();
		
		//randomly generate 20 processes (and the resources they require) and add them to myList
		int counter;
		for(counter = 0; counter < 20; counter++) {
			String resource;
			int random_int = rand.nextInt(7);
			if (random_int == 0) { resource = "A"; }
			else if (random_int == 1) { resource = "B"; myList.addLast(resource);}
			else if (random_int == 2) { resource = "C"; myList.addLast(resource);}
			else if (random_int == 3) { resource = "A,B"; myList.addLast(resource);}
			else if (random_int == 4) { resource = "A,C"; myList.addLast(resource);}
			else if (random_int == 5) { resource = "B,C";  myList.addLast(resource);}
			else if (random_int == 6) { resource = "A,B,C";  myList.addLast(resource);}
			else {System.out.println("Error: Resource not generated correctly.");}
			
		}
		
		//now start executing cycles!
		int cycle = 0;
		
		//make while loop to run cycles and execute processes in the Singly Linked List
		while (!myList.isEmpty()) {
			
			//if the loop has reached cycle 1000, but the singly linked list is not empty, print the number of processes left
			//and break the cycling.
			if (cycle == 1000) {
				System.out.println("Length of processes at cycle 1000: " + myList.size());
				break;
			}
			
			//every 100th cycle, print out the length of processes remaining.
			if (cycle % 100 == 0 && cycle != 0) {
				
				//print out length of SinglyLinkedList (which is the number of unexecuted processes)
				System.out.println("Length of processes at cycle " + cycle + ": " + myList.size());
				
				//every 100th cycle, output the number of cycles needed to empty the list of processes
				try {
					
					//variable to keep track of number of cycles needed to empty list
					int needed_cycles = 0;
					
					//clone the list
					SinglyLinkedList<String> myListcopy = myList.clone();
					
					//execute the processes of the cloned list, using needed_cycles variable to keep track
					while (!myListcopy.isEmpty()) {
						
						//track cycle number
						needed_cycles += 1;
						
						//get node1 and its required resources
						String node1_copy = myListcopy.first();
						//remove the first node so that we can access the second node using first()
						myListcopy.removeFirst();
						
						//get node2 and its required resources
						String node2_copy = myListcopy.first();
						
							//if node2 is not empty
							if (node2_copy != null) {
								//if node1 and node2 need any of the same resources, only process node1 and move onto the next iteration
								if ((node1_copy.contains("A") && node2_copy.contains("A")) || (node1_copy.contains("B") && node2_copy.contains("B")) || (node1_copy.contains("C") && node2_copy.contains("C"))) {
									continue;
								}
								
								//if node1 and node2 do NOT share resources, remove node2 and move on to compare node1 and node2 with node3
								else {
									myListcopy.removeFirst();
									String node3_copy = myListcopy.first();
									
									//if node3 is not empty
									if (node3_copy != null) {
										if ((node1_copy.contains("A") && node3_copy.contains("A")) || (node1_copy.contains("B") && node3_copy.contains("B")) || (node1_copy.contains("C") && node3_copy.contains("C")) ||
											(node2_copy.contains("A") && node3_copy.contains("A")) || (node2_copy.contains("B") && node3_copy.contains("B")) || (node2_copy.contains("C") && node3_copy.contains("C"))) {
											continue;
										}
										//if none of the nodes share resources, then remove node3 from the singly linked list and include it in the cycle.
										else {
											myListcopy.removeFirst();
										}
									}
								}
								
							}
					}
					
					
					//print out number of cycles needed to empty
					System.out.println("Number of cycles needed to empty list: " + needed_cycles);
					System.out.println("\n");
				}
				
				//use catch block to check CloneNotSupportedException, since we are cloning myList
				catch (CloneNotSupportedException e) {
					e.printStackTrace();
				}
			}
			
			// increase cycle number by 1 since we are moving onto the next cycle where we will execute more process(es)
			cycle += 1;
			
			//add 2 processes to the end of the list
			for(int counter2 = 0; counter2 < 2; counter2++) {
				String resource;
				int random_int = rand.nextInt(7);
				if (random_int == 0) { resource = "A"; }
				else if (random_int == 1) { resource = "B"; myList.addLast(resource);}
				else if (random_int == 2) { resource = "C"; myList.addLast(resource);}
				else if (random_int == 3) { resource = "A,B"; myList.addLast(resource);}
				else if (random_int == 4) { resource = "A,C"; myList.addLast(resource);}
				else if (random_int == 5) { resource = "B,C";  myList.addLast(resource);}
				else if (random_int == 6) { resource = "A,B,C";  myList.addLast(resource);}
				else {System.out.println("Error: Resource not generated correctly.");}
			}
			
			//get node1 and its required resources
			String node1 = myList.first();
			//remove the first node so that we can access the second node using first()
			myList.removeFirst();
			
			//get node2 and its required resources
			String node2 = myList.first();
			
				//if node2 is not empty
				if (node2 != null) {
					//if node1 and node2 need any of the same resources, only process node1 and move onto the next iteration
					if ((node1.contains("A") && node2.contains("A")) || (node1.contains("B") && node2.contains("B")) || (node1.contains("C") && node2.contains("C"))) {
						continue;
					}
					
					//if node1 and node2 do NOT share resources, remove node2 and move on to compare node1 and node2 with node3
					else {
						myList.removeFirst();
						String node3 = myList.first();
						
						//if node3 is not empty
						if (node3 != null) {
							if ((node1.contains("A") && node3.contains("A")) || (node1.contains("B") && node3.contains("B")) || (node1.contains("C") && node3.contains("C")) ||
								(node2.contains("A") && node3.contains("A")) || (node2.contains("B") && node3.contains("B")) || (node2.contains("C") && node3.contains("C"))) {
								//if either node1 or node2 share resources with node3, do not execute node3 and move onto the next cycle.
								continue;
							}
							//if none of the nodes share resources, then remove node3 from the singly linked list and include it in the cycle.
							else {
								myList.removeFirst();
							}
						}
					}
				}
		}
	}
}