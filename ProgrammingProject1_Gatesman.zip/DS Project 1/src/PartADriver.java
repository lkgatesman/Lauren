
import java.io.File;	//import to be able to read files
import java.io.FileNotFoundException;	//import to handle file exceptions
import java.util.*;	//import to read text files
import net.datastructures.*; //import to use methods for SinglyLinkedList Object

public class PartADriver{
	public static void main (String[] args) {
		//try catch blocks in case file is not opened
		try {
			//open file
			File TestCases = new File (System.getProperty("user.dir") + "/TestCases.txt");
			//make scanner to read from file
			Scanner InputReader = new Scanner(TestCases);
		
			int lineNum;	//variable to move from line to line in TestCase.txt file
			int index;		//variable to keep track of process
			
			//repeat this process for each line of the text file, of which there are 10 total.
			for (lineNum = 1; lineNum <= 10; lineNum++) {
				
				//declare and instantiate SinglyLinkedList where resources for each set of processes will be stored
				SinglyLinkedList<String> myResources;
				myResources = new SinglyLinkedList<String>();
				
				//read line of TestCase.txt
				String thisLine = InputReader.nextLine();
				
				//store each process as an element of an array
				String[] processes = thisLine.split(";");
				
				//use for loop to go through each element of the array of processes, extract its required resources, 
				//and add the resources as a new node to the Singly Linked List
				for (index = 0; index < 10; index++) {
					String resource = processes[index].substring(processes[index].indexOf("(")+1,processes[index].indexOf(")"));
					myResources.addLast(resource);
				}
				
				//now start executing cycles!
				int cycle = 0;
				
				//make while loop to run cycles
				while (!myResources.isEmpty()) {
					
					//track cycle number
					cycle += 1;
					
					//get node1 and its required resources
					String node1 = myResources.first();
					//remove the first node so that we can access the seconde node using first()
					myResources.removeFirst();
					
					//get node2 and its required resources
					String node2 = myResources.first();
					
						//if node2 is not empty
						if (node2 != null) {
							//if node1 and node2 need any of the same resources, only process node1 and move onto the next iteration
							if ((node1.contains("A") && node2.contains("A")) || (node1.contains("B") && node2.contains("B")) || (node1.contains("C") && node2.contains("C"))) {
								continue;
							}
							
							//if node1 and node2 do NOT share resources, remove node2 and move on to compare node1 and node2 with node3
							else {
								myResources.removeFirst();
								String node3 = myResources.first();
								
								//if node3 is not empty
								if (node3 != null) {
									if ((node1.contains("A") && node3.contains("A")) || (node1.contains("B") && node3.contains("B")) || (node1.contains("C") && node3.contains("C")) ||
										(node2.contains("A") && node3.contains("A")) || (node2.contains("B") && node3.contains("B")) || (node2.contains("C") && node3.contains("C"))) {
										continue;
									}
									//if none of the nodes share resources, then remove node3 from the singly linked list and include it in the cycle.
									else {
										myResources.removeFirst();
									}
								}
							}
						}
				}
				
				//print out the number of cycles needed for each list of processes
				System.out.println("Number of Cycles Required for List #" + lineNum + ":\t" + cycle);
				
			}
			
			//close Scanner for reading from text file
			InputReader.close();
		}
		
		//catch block in case file isn't found. Print out appropriate error messages.
		catch (FileNotFoundException e){
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
}